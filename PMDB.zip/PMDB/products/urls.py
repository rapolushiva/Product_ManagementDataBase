from django.urls import path
from .views import ShowAllProducts
from .views import productDetail
from .views import addProduct
from .views import updateProduct
from .views import deleteProduct
from .views import searchbar


from products import views

urlpatterns= [
    path('',views.ShowAllProducts,name='ShowProducts'),
    path('product/<int:pk>', views.productDetail, name='ProductDetails'),
    path('addproduct',views.addProduct , name='addproduct'),
    path('updateproduct/<int:pk>',views.updateProduct , name='updateproduct'),
    path('deleteproduct/<int:pk>',views.deleteProduct , name='deleteproduct'),
    path('search/',views.searchbar , name='searchbar')

]

#static ,dynamic,cms:content management system,or midd levelprojects,erp