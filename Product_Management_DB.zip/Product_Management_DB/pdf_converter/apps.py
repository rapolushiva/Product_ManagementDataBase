from django.apps import AppConfig


class PdfConverterConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "pdf_converter"
