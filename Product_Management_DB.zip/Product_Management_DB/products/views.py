from.models import Product,Category
from django.shortcuts import render,redirect
from django.core.paginator import Paginator,PageNotAnInteger,EmptyPage
from django.contrib.auth.decorators import login_required
#view all the products
@login_required()
def ShowAllProducts(request):
    # products=Product.objects.all()
    # products=Product.objects.filter(is_published=True).order_by('price')
    # products=Product.objects.filter(is_published=True).order_by('-price')
    category = request.GET.get('category')

    if category ==None:
        products=Product.objects.filter(is_published=True).order_by('created_at')

    else:
        products=Product.objects.filter(category__name=category)


    total_product=Product.objects.all().count()
    page_num=request.GET.get('page')            #creating the total pages
    paginator = Paginator(products,3)           #seting total number of products in a page:3
    try:
        products=paginator.page(page_num)
    except PageNotAnInteger:
        products=paginator.page(1)
    except EmptyPage:
        products=paginator.page(paginator.num_pages )

    categories =Category.objects.all()


    context={
        'products':products,
        'categories':categories,
       
    }
    return render (request,'ShowProducts.html',context)



@login_required()
#To view the single product based on our requirements
def productDetail(request,pk): #primary key 
    eachproduct=Product.objects.get(id=pk)
    context={
        'eachproduct':eachproduct
    }
    return render(request, 'ProductDetail.html', context)




#TO ADD the new products particular page
from .forms import ProductForm
@login_required()
def addProduct(request):
    form=ProductForm()

    if request.method=="POST":
        form =ProductForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            return redirect('ShowProducts')
    context={
        "forms":form
    }
    return render(request,'AddProduct.html',context)


@login_required()
def updateProduct(request,pk):
    product=Product.objects.get(id=pk)
    form=ProductForm(instance=product)
    if request.method=="POST":
        form=ProductForm(request.POST, request.FILES, instance=product)
        form.save()
        return redirect('ShowProducts')
    context={
        "form":form
    }
    return render(request,'UpdateProduct.html',context)


def deleteProduct(request,pk):
    product=Product.objects.get(id=pk)   #storing record number like 1,2,3,4 in product
    product.delete()                     #particular Record=1
    
    return redirect ('ShowAllProducts')

@login_required()
def searchbar(request):
    if request.method =='GET':
        query=request.GET.get('query')
        if query:
            product=Product.objects.filter(name__contains=query)                                 #999
            return render(request,'searchbar.html',{'products':product})
        else:
            print("no products in database")
            return render( request,'searchbar.html',{})